
<section class="testimonials-style2-area pdbtm150">
    <div class="round-shape-box1 wow slideInRight" data-wow-delay="400ms" data-wow-duration="6500ms">
        <img src="assets/images/shape/shape-round-5.png" alt="">
    </div>
    <div class="container">
        <div class="sec-title text-center">
            <div class="sub-title">
                <p>Testimonials</p>
            </div>
            <h2>What Our Client Are Saying<br> About Homepro</h2>
        </div>
        <div class="row">
            <div class="col-xl-12">
                <div class="testimonials-style1__content wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                    <div class="theme_carousel testimonials-carousel_1 owl-dot-style1 owl-theme owl-carousel" data-options='{"loop": true, "margin": 30, "autoheight":true, "lazyload":true, "nav": false, "dots": true, "autoplay": true, "autoplayTimeout": 6000, "smartSpeed": 300, "responsive":{ "0" :{ "items": "1" }, "600" :{ "items" : "1" }, "768" :{ "items" : "1" } , "992":{ "items" : "2" }, "1200":{ "items" : "3" }}}'>
                        <!--Start Single Testimonials Style1-->
                        <div class="single-testimonials-style1">
                            <div class="client-info">
                                <div class="img-box">
                                    <img src="assets/images/testimonial/testimonial-v1-1.jpg" alt=""/>
                                </div>
                                <div class="title-box">
                                    <h3>Nicolas Lawson</h3>
                                    <span>Designer</span>
                                </div>
                            </div>
                            <div class="text">
                                <p>Lorem ipsum dolor amet consetur adipicing elit sed do umod tempor incididunt enim.</p>
                                <div class="date-box"><p>Tuesday, 29 June, 2021</p></div>
                            </div>
                        </div>
                        <!--End Single Testimonials Style1-->
                        <!--Start Single Testimonials Style1-->
                        <div class="single-testimonials-style1">
                            <div class="client-info">
                                <div class="img-box">
                                    <img src="assets/images/testimonial/testimonial-v1-2.jpg" alt=""/>
                                </div>
                                <div class="title-box">
                                    <h3>Nicolas Lawson</h3>
                                    <span>Designer</span>
                                </div>
                            </div>
                            <div class="text">
                                <p>Lorem ipsum dolor amet consetur adipicing elit sed do umod tempor incididunt enim.</p>
                                <div class="date-box"><p>Tuesday, 29 June, 2021</p></div>
                            </div>
                        </div>
                        <!--End Single Testimonials Style1-->
                        <!--Start Single Testimonials Style1-->
                        <div class="single-testimonials-style1">
                            <div class="client-info">
                                <div class="img-box">
                                    <img src="assets/images/testimonial/testimonial-v1-3.jpg" alt=""/>
                                </div>
                                <div class="title-box">
                                    <h3>John Smith</h3>
                                    <span>Designer</span>
                                </div>
                            </div>
                            <div class="text">
                                <p>Lorem ipsum dolor amet consetur adipicing elit sed do umod tempor incididunt enim.</p>
                                <div class="date-box"><p>Tuesday, 29 June, 2021</p></div>
                            </div>
                        </div>
                        <!--End Single Testimonials Style1-->

                        <!--Start Single Testimonials Style1-->
                        <div class="single-testimonials-style1">
                            <div class="client-info">
                                <div class="img-box">
                                    <img src="assets/images/testimonial/testimonial-v1-1.jpg" alt=""/>
                                </div>
                                <div class="title-box">
                                    <h3>Nicolas Lawson</h3>
                                    <span>Designer</span>
                                </div>
                            </div>
                            <div class="text">
                                <p>Lorem ipsum dolor amet consetur adipicing elit sed do umod tempor incididunt enim.</p>
                                <div class="date-box"><p>Tuesday, 29 June, 2021</p></div>
                            </div>
                        </div>
                        <!--End Single Testimonials Style1-->
                        <!--Start Single Testimonials Style1-->
                        <div class="single-testimonials-style1">
                            <div class="client-info">
                                <div class="img-box">
                                    <img src="assets/images/testimonial/testimonial-v1-2.jpg" alt=""/>
                                </div>
                                <div class="title-box">
                                    <h3>Nicolas Lawson</h3>
                                    <span>Designer</span>
                                </div>
                            </div>
                            <div class="text">
                                <p>Lorem ipsum dolor amet consetur adipicing elit sed do umod tempor incididunt enim.</p>
                                <div class="date-box"><p>Tuesday, 29 June, 2021</p></div>
                            </div>
                        </div>
                        <!--End Single Testimonials Style1-->
                        <!--Start Single Testimonials Style1-->
                        <div class="single-testimonials-style1">
                            <div class="client-info">
                                <div class="img-box">
                                    <img src="assets/images/testimonial/testimonial-v1-3.jpg" alt=""/>
                                </div>
                                <div class="title-box">
                                    <h3>Nicolas Lawson</h3>
                                    <span>Designer</span>
                                </div>
                            </div>
                            <div class="text">
                                <p>Lorem ipsum dolor amet consetur adipicing elit sed do umod tempor incididunt enim.</p>
                                <div class="date-box"><p>Tuesday, 29 June, 2021</p></div>
                            </div>
                        </div>
                        <!--End Single Testimonials Style1-->

                        <!--Start Single Testimonials Style1-->
                        <div class="single-testimonials-style1">
                            <div class="client-info">
                                <div class="img-box">
                                    <img src="assets/images/testimonial/testimonial-v1-1.jpg" alt=""/>
                                </div>
                                <div class="title-box">
                                    <h3>Nicolas Lawson</h3>
                                    <span>Designer</span>
                                </div>
                            </div>
                            <div class="text">
                                <p>Lorem ipsum dolor amet consetur adipicing elit sed do umod tempor incididunt enim.</p>
                                <div class="date-box"><p>Tuesday, 29 June, 2021</p></div>
                            </div>
                        </div>
                        <!--End Single Testimonials Style1-->
                        <!--Start Single Testimonials Style1-->
                        <div class="single-testimonials-style1">
                            <div class="client-info">
                                <div class="img-box">
                                    <img src="assets/images/testimonial/testimonial-v1-2.jpg" alt=""/>
                                </div>
                                <div class="title-box">
                                    <h3>Nicolas Lawson</h3>
                                    <span>Designer</span>
                                </div>
                            </div>
                            <div class="text">
                                <p>Lorem ipsum dolor amet consetur adipicing elit sed do umod tempor incididunt enim.</p>
                                <div class="date-box"><p>Tuesday, 29 June, 2021</p></div>
                            </div>
                        </div>
                        <!--End Single Testimonials Style1-->
                        <!--Start Single Testimonials Style1-->
                        <div class="single-testimonials-style1">
                            <div class="client-info">
                                <div class="img-box">
                                    <img src="assets/images/testimonial/testimonial-v1-3.jpg" alt=""/>
                                </div>
                                <div class="title-box">
                                    <h3>Nicolas Lawson</h3>
                                    <span>Designer</span>
                                </div>
                            </div>
                            <div class="text">
                                <p>Lorem ipsum dolor amet consetur adipicing elit sed do umod tempor incididunt enim.</p>
                                <div class="date-box"><p>Tuesday, 29 June, 2021</p></div>
                            </div>
                        </div>
                        <!--End Single Testimonials Style1-->
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>