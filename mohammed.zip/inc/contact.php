<section class="contact-style1-area">
    <div class="shape1">
        <img class="paroller-2" src="images/contact-style1-shape-1.png" alt>
    </div>
    <div class="shape2">
        <img class="zoom-fade" src="images/contact-style1-shape-2.png" alt>
    </div>
    <div class="shape3 float-bob-y" style="background-image: url(images/contact-style1-shape-3.png);"></div>
    <div class="container">
        <div class="row">
            <div class="col-xl-4">
                <div class="contact-style1__image wow slideInLeft" data-wow-delay="100ms" data-wow-duration="2500ms">
                    <img src="images/house-1.png" alt>
                </div>
            </div>
            <div class="col-xl-8">
                <div class="contact-form-box1">
                    <div class="top-title">
                        <h2>Need To Contact Us?<br /> Feel free and submit the following form</h2>
                    </div>
                    <div class="button-box">
                        <a href="<?=$webBaseUrl?>contact.php" class="btn-one style2">
                            <span class="txt">Contact Now</span>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>