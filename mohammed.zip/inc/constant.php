<?php
$w3Name = "Mohammed";
$w3Description = "A Website For selling properties";
$w3LongDescription = "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam at, error quidem, sit voluptatem aut deleniti maxime praesentium exercitationem odit, minima illum distinctio omnis! Reprehenderit!";
$w3Phone = "0123456789";
$w3Email = "xyz@gmail.com";
$w3Address = "123 Main Street";

if ($_SERVER['HTTP_HOST'] == "localhost") {
    $webBaseUrl = "http://localhost/mohammed/";
} else {
    $webBaseUrl = "http://www.mohammed.com/";
}
?>